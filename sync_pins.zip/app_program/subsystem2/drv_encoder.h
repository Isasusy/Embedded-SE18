/*
 *	drv_encoder.h / drv_encoder.c
 *	Subsystem 2 -- wheel encoders, quadrature x4, decoded by POLLING (no interrupts, no Pico SDK).
 *	Left: GP2 (A) / GP3 (B).  Right: GP4 (A) / GP5 (B).
 *	enc_task (subsystem2.c) calls enc_poll() every 1 ms; motion_task calls enc_read().
 *	Limit: a wheel edge rate above ~500 edges/s per channel can be missed (the 1 ms tick). Fine at line-following speed.
 */
#ifndef DRV_ENCODER_H
#define DRV_ENCODER_H

#include <stdint.h>

#define ENC_L_A		2
#define ENC_L_B		3
#define ENC_R_A		4
#define ENC_R_B		5

void	enc_init(void);
void	enc_poll(void);					/* sample the four pins once and update the counts */
void	enc_read(int32_t *left, int32_t *right);	/* cumulative edge counts, forward positive */

#endif
