/* s3_port.h -- subsystem 3: console print, microsecond timer, ms clock. Fix build problems here first. */
#ifndef S3_PORT_H
#define S3_PORT_H

#ifndef S3_PRINTF
#define S3_PRINTF(...)		tm_printf((UB*)__VA_ARGS__)	/* the template console (USB serial) */
#endif
/* RP2040 free-running 1 MHz timer, TIMERAWL (read-only register; no SDK needed) */
#define S3_US32()		(*(volatile unsigned int *)0x40054028u)
static inline uint32_t s3_now_ms(void) { SYSTIM t; tk_get_otm(&t); return (uint32_t)t.lo; }
#endif
