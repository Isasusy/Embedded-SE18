#include "subsystem2.h"
#include <bsp/libbsp.h>
#include "drv_encoder.h"
#include "motion_config.h"

static volatile int32_t	s_cnt_l, s_cnt_r;
static uint8_t		s_prev_l, s_prev_r;

/* index = (previous state << 2) | new state, state = (A << 1) | B.  Gray sequence 00 01 11 10 = +1 */
static const int8_t qtab[16] = { 0, +1, -1, 0,  -1, 0, 0, +1,  +1, 0, 0, -1,  0, -1, +1, 0 };

static uint8_t state(unsigned pa, unsigned pb)
{
	return (uint8_t)(((gpio_get_val(pa) ? 1u : 0u) << 1) | (gpio_get_val(pb) ? 1u : 0u));
}

/* pull-up on a pad (PADS_BANK0: GPIOn at 0x4001C004 + 4n; PUE = bit 3, PDE = bit 2) */
static void pull_up(unsigned pin)
{
	volatile unsigned int *pad = (volatile unsigned int *)(0x4001C004u + 4u * pin);
	*pad = (*pad | (1u << 3)) & ~(1u << 2);
}

void enc_init(void)
{
	for (unsigned p = ENC_L_A; p <= ENC_R_B; p++) {
		gpio_set_pin(p, GPIO_MODE_IN);
		pull_up(p);
	}
	s_prev_l = state(ENC_L_A, ENC_L_B);
	s_prev_r = state(ENC_R_A, ENC_R_B);
}

void enc_poll(void)
{
	uint8_t nl = state(ENC_L_A, ENC_L_B);
	uint8_t nr = state(ENC_R_A, ENC_R_B);

	s_cnt_l += MC_ENC_L_SIGN * qtab[(s_prev_l << 2) | nl];
	s_cnt_r += MC_ENC_R_SIGN * qtab[(s_prev_r << 2) | nr];
	s_prev_l = nl;
	s_prev_r = nr;
}

void enc_read(int32_t *left, int32_t *right)
{
	*left = s_cnt_l;
	*right = s_cnt_r;
}
