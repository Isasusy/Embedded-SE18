/*
 *	scan_algo.h / scan_algo.c -- Obstacle Scan logic: turns one servo sweep into obstacle_t
 *	(width, clearance each side, chosen side). No hardware: testable on a PC.
 */
#ifndef SCAN_ALGO_H
#define SCAN_ALGO_H

#include "vc_msgs.h"

#define SCAN_MAX_RAYS	32

/* angles in degrees ASCENDING (most right first), + = left, evenly spaced; dist_mm < 0 = no echo (treated as clear) */
void scan_analyze(const int *angle_deg, const int *dist_mm, int n, obstacle_t *out);

#endif
