#include <string.h>
#include "barcode_algo.h"
#include "line_config.h"
#include "../subsystem5/vc_msgs.h"

void bd_init(bd_t *b) { memset(b, 0, sizeof *b); }

static int code_to_nav(int code)
{
	switch (code) {
	case BAR_CODE_LEFT:	return NAV_LEFT;
	case BAR_CODE_RIGHT:	return NAV_RIGHT;
	case BAR_CODE_STRAIGHT:	return NAV_STRAIGHT;
	case BAR_CODE_UTURN:	return NAV_UTURN;
	case BAR_CODE_STOP:	return NAV_STOP;
	default:		return -1;
	}
}

static bd_result_t decode(bd_t *b, int *nav, int *code)
{
	uint32_t ref = b->width_us[0];
	int v = 0;
	for (int i = 1; i < BAR_COUNT; i++) {
		bool wide = (float)b->width_us[i] > BAR_WIDE_RATIO * (float)ref;
		v = (v << 1) | (wide ? 1 : 0);
	}
	*code = v;
	int n = code_to_nav(v);
	if (n < 0) return BD_INVALID;
	*nav = n;
	return BD_VALID;
}

static void reset(bd_t *b) { memset(b, 0, sizeof *b); }

bd_result_t bd_edge(bd_t *b, uint32_t t_us, bool black, int *nav, int *code)
{
	if (b->active && (uint32_t)(t_us - b->last_edge_us) > BAR_TIMEOUT_US) {
		reset(b);				/* went quiet: this edge starts a new read */
	}
	if (black) {					/* start of a bar */
		if (!b->active) { reset(b); b->active = true; }
		b->in_bar = true;
		b->t_rise_us = t_us;
		b->last_edge_us = t_us;
		return BD_NONE;
	}
	if (!b->active || !b->in_bar)			/* white edge without a bar */
		return BD_NONE;
	uint32_t w = t_us - b->t_rise_us;		/* end of a bar */
	b->in_bar = false;
	b->last_edge_us = t_us;
	if (w < BAR_MIN_US || w > BAR_MAX_US) {
		reset(b);
		return BD_INVALID;
	}
	b->width_us[b->bars++] = w;
	if (b->bars < BAR_COUNT)
		return BD_NONE;
	bd_result_t r = decode(b, nav, code);
	reset(b);
	return r;
}

bd_result_t bd_poll(bd_t *b, uint32_t now_us)
{
	if (b->active && (uint32_t)(now_us - b->last_edge_us) > BAR_TIMEOUT_US) {
		reset(b);
		return BD_INVALID;
	}
	return BD_NONE;
}
