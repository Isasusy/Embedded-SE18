/*
 *	vc_config.h -- every tunable number of subsystem 5 (Vehicle Controller + obstacle scan).
 */
#ifndef VC_CONFIG_H
#define VC_CONFIG_H

/* ---- Vehicle Controller ---- */
#define VC_TICK_MS		20		/* event-driven plus 20 ms tick (task table) */
#define VC_CRUISE_SPEED		150		/* mm/s, normal line following            */
#define VC_HUMP_SPEED		90		/* mm/s while the IMU measures a hump     */
#define VC_RECOVER_SPEED	60		/* mm/s while searching for a lost line   */
#define VC_TURN_ANGLE		90		/* degrees for a LEFT / RIGHT barcode     */
#define VC_SELFTEST_MS		4000		/* INIT: all subsystems must report READY in this time */
#define VC_ALIVE_MS		100		/* NFR10: a task silent longer than this = fault */
#define VC_RECOVER_TIMEOUT_MS	4000
#define VC_HUMP_TIMEOUT_MS	6000
#define VC_SCAN_TIMEOUT_MS	6000
#define VC_SEARCH_TIMEOUT_MS	5000
#define VC_STATUS_MS		500		/* NFR5: telemetry at 2 Hz */
#define VC_SETTLE_TICKS		2		/* ignore cmd_done this long after sending a manoeuvre */

/* ---- obstacle bypass geometry (CALIBRATE on the robot) ---- */
#define VC_ROBOT_HALF_W_MM	80
#define VC_SIDE_MARGIN_MM	40
#define VC_OBST_DEPTH_MM	200		/* the ultrasonic sensor cannot measure depth: assumed from the track briefing */
#define VC_ROBOT_LEN_MM		150

/* ---- hardware watchdog (NFR10: 500 ms) ---- */
#define VC_WATCHDOG_ENABLE	0		/* 1 at integration; 0 on the bench so a stand-alone S5 does not reset */
#define VC_WATCHDOG_MS		500

/* ---- bench start: no MQTT needed ----
   0 = wait for a REMOTE_START (from S1/MQTT). N > 0 = start the mission by itself N ms after power-up, once,
   as soon as every subsystem reports READY. LIFT THE WHEELS OFF THE TABLE FIRST. Set 0 at integration. */
#define VC_AUTOSTART_MS		0

/* ---- Obstacle Scan ---- */
#define SCAN_PERIOD_MS		60		/* ping period while WATCHing (task table: 60 ms per ping) */
#define SCAN_CLOSE_MM		180		/* WATCH: closer than this twice in a row = obstacle close */
#define SCAN_NEAR_MM		400		/* a ray shorter than this belongs to the obstacle */
#define SCAN_MIN_CLEAR_MM	150		/* a side narrower than this cannot be used */
#define SCAN_ANGLE_MAX		40		/* sweep -40 .. +40 degrees (+ = left) */
#define SCAN_ANGLE_STEP		4
#define SCAN_SETTLE_MS		60		/* servo settling time per angle */
#define SERVO_US_MIN		500		/* SG90 pulse widths */
#define SERVO_US_MAX		2500
#define SERVO_TRIM_DEG		0		/* adjust if "straight ahead" is not 0 */

#define S5_DEBUG_PRINT		1
#endif
