/* Build and run: cc -O1 -I../../../app_program/subsystem3 -o barsim barcode_sim.c ../../../app_program/subsystem3/barcode_algo.c -lm
   ./barsim <spot sigma mm> <speed mm/s> <swing> <0 = peak detector, N = fixed threshold N> */
/* Simulate the IR barcode sensor over the course's "*A*" (narrow 3 mm, wide 9 mm), blurred by the IR spot. */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../../../app_program/subsystem3/barcode_algo.h"
static const char *pat[] = { "010010100", "100001001", "010010100" };	/* * A * */
static double g_scale = 1.0;
static int black_at(double x)		/* x in mm from the code start; 1 = black */
{
	double p = 0;
	x /= g_scale;
	for (int c = 0; c < 3; c++) {
		for (int i = 0; i < 9; i++) {
			double w = pat[c][i] == '1' ? 9 : 3;
			if (x >= p && x < p + w) return (i % 2) == 0;
			p += w;
		}
		if (c < 2) { if (x >= p && x < p + 3) return 0; p += 3; }
	}
	return 0;
}
static double sensor(double x, double sigma)	/* gaussian spot */
{
	double s = 0, n = 0;
	for (double d = -3 * sigma; d <= 3 * sigma; d += 0.1) { double g = exp(-d * d / (2 * sigma * sigma)); s += g * black_at(x + d); n += g; }
	return 220 + (2100 - 220) * s / n + (rand() % 61 - 30);
}
int main(int argc, char **argv)
{
	double sigma = argc > 1 ? atof(argv[1]) : 2.0, speed = argc > 2 ? atof(argv[2]) : 100.0;
	int swing = argc > 3 ? atoi(argv[3]) : 150, fixed = argc > 4 ? atoi(argv[4]) : 0;
	g_scale = argc > 5 ? atof(argv[5]) : 1.0;		/* print size: 1 = narrow 3 mm, 2 = narrow 6 mm ... */
	bd_t b; bd_init(&b); bd_read_t rd; bd_result_t r = BD_NONE;
	int last = 0, ext = 220; uint32_t t = 1000;
	for (double x = -60; x < 300 * g_scale && r == BD_NONE; x += speed / 1000.0, t += 1000) {
		int v = (int)sensor(x, sigma), level = last;
		if (fixed) level = last ? (v > fixed - 100) : (v > fixed + 100);
		else if (!last) { if (v < ext) ext = v; if (v > ext + swing) level = 1; }
		else { if (v > ext) ext = v; if (v < ext - swing) level = 0; }
		if (level != last) { int pk = ext; last = level; ext = v; bd_edge_p(&b, t, level == 1, pk); }
		r = bd_poll(&b, t, &rd);
	}
	printf("size x%.2f sigma %.1f mm speed %.0f %s: %s \"%s\" pattern %s (%d elements)\n", g_scale, sigma, speed, fixed ? "fixed" : "peak",
	       r == BD_VALID ? "VALID" : r == BD_INVALID ? "INVALID" : "none", rd.text, rd.pattern, rd.n_elements);
	return 0;
}
