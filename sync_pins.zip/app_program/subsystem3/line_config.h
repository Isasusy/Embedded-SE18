/*
 *	line_config.h -- every tunable number of subsystem 3 (line following + barcode).
 */
#ifndef LINE_CONFIG_H
#define LINE_CONFIG_H

/* ---- line following (FR1, NFR1: 5 ms) ---- */
#define LINE_PERIOD_MS		5
#define LINE_CAL_MS		2000		/* calibration window: rock the robot across the line by hand */
#define LINE_CAL_MIN_RANGE	400		/* ADC counts (0..4095); smaller spread = calibration rejected, defaults used */
#define LINE_DEF_WHITE		800		/* defaults if calibration is rejected */
#define LINE_DEF_BLACK		3000
#define LINE_BLACK_IS_HIGH	1		/* 1 = ADC reading rises over black (TCRT5000 analog module) */
#define LINE_ON_THRESH		0.5f		/* normalised reading (0 white .. 1 black) counted as "on black" */
#define LINE_STEER_GAIN		120.0f		/* mm/s of wheel-speed difference per unit of offset (-1..+1) */
#define LINE_JUNCTION_MS	30		/* both sensors black this long = junction */
#define LINE_LOST_MS		250		/* both sensors white this long = line lost */

/* ---- barcode (FR2, NFR1: microsecond timestamps) ----
 * PLACEHOLDER CODE (the briefing's real barcode format was not in the design review):
 *   4 black bars. Bar 1 is always NARROW and is the width reference.
 *   Bars 2..4: wide (> BAR_WIDE_RATIO x bar 1) = 1, narrow = 0. Value = b2*4 + b3*2 + b4.
 *   Because every width is compared to bar 1, the decode does not depend on robot speed.
 * Change barcode_algo.c (bd_decode) when the real format is known. */
#define BAR_COUNT		4
#define BAR_WIDE_RATIO		1.6f
#define BAR_MIN_US		3000		/* narrower than this = noise (GP28 is polled every 1 ms, not interrupt-timed) */
#define BAR_MAX_US		200000		/* wider than this = not a bar */
#define BAR_TIMEOUT_US		300000		/* no edge for this long mid-read = discard */
#define BARCODE_BLACK_IS_HIGH	1		/* GP28 level over a black bar */

/* code value -> navigation command (value is b2*4 + b3*2 + b4); -1 = invalid */
#define BAR_CODE_LEFT		0
#define BAR_CODE_RIGHT		1
#define BAR_CODE_STRAIGHT	2
#define BAR_CODE_UTURN		3
#define BAR_CODE_STOP		7

#define S3_DEBUG_PRINT		1		/* print events and a 2 Hz line; 0 at integration */

#endif
