/* Bench line follow: after START the car creeps at VC_BENCH_SPEED and nothing but STOP / a fault stops it. */
#include <stdio.h>
#include <string.h>
#include "../../../app_program/subsystem5/vc_logic.h"
#include "../../../app_program/subsystem5/vc_config.h"

static int checks, fails;
#define CHECK(c, ...) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static vc_t v; static vc_out_t o; static uint32_t now = 1000;
static const obstacle_t *g_obst;
static bool g_mfault;
static void tick(const remote_cmd_t *r, const nav_cmd_t *n, const line_evt_t *l, const imu_evt_t *i, bool close)
{
	vc_in_t in = { .now_ms = now += VC_TICK_MS, .remote = r, .nav = n, .line = l, .imu = i, .obst = g_obst,
		       .obstacle_close = close, .motion_fault = g_mfault, .all_ready = true, .all_alive = true };
	vc_step(&v, &in, &o);
}

int main(void)
{
	remote_cmd_t START = { REMOTE_START }, STOP = { REMOTE_STOP };
	nav_cmd_t left = { NAV_LEFT, 0, 0 }, stop = { NAV_STOP, 0, 0 };
	line_evt_t junc = { LINE_EVT_JUNCTION, 0 }, lost = { LINE_EVT_LOST, 0 };
	imu_evt_t sf; memset(&sf, 0, sizeof sf); sf.type = IMU_EVT_SENSOR_FAULT;
	imu_evt_t hit; memset(&hit, 0, sizeof hit); hit.type = IMU_EVT_IMPACT;

	vc_init(&v);
	tick(0, 0, 0, 0, false); tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_IDLE, "self-test -> IDLE");
	tick(&START, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && o.motion.type == MOTION_CMD_GO && o.motion.speed_mm_s == VC_BENCH_SPEED,
	      "START -> GO at the slow bench speed (%d)", (int)o.motion.speed_mm_s);

	for (int k = 0; k < 50; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && !o.send_motion, "keeps creeping, no new commands");
	tick(0, 0, &junc, 0, false);
	CHECK(v.state == (VC_JUNCTION_PAUSE_ALWAYS ? VC_BARCODE_ACTION : VC_LINE_FOLLOW), "a junction with no barcode: pause");
	for (int k = 0; k < VC_JUNCTION_PAUSE_MS / VC_TICK_MS + 2; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW, "... then straight on");
	tick(0, &left, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && !o.send_motion, "barcode LEFT: remembered, keeps driving");
	for (int k = 0; k < 50; k++) tick(0, 0, 0, 0, false);
	tick(0, 0, &junc, 0, false);
#if VC_BENCH_BARCODES
	CHECK(v.state == VC_BARCODE_ACTION && o.motion.type == MOTION_CMD_STOP, "then at the junction: stop");
	for (int k = 0; k < VC_JUNCTION_PAUSE_MS / VC_TICK_MS; k++) tick(0, 0, 0, 0, false);
	CHECK(o.motion.type == MOTION_CMD_MOVE, "after the pause: drive to its centre");
	for (int k = 0; k < 5; k++) tick(0, 0, 0, 0, false);
	{ vc_in_t in = { .now_ms = now += VC_TICK_MS, .motion_done = true, .all_ready = true, .all_alive = true }; vc_step(&v, &in, &o); }
	CHECK(o.send_motion && o.motion.type == MOTION_CMD_TURN && o.motion.angle_deg == VC_TURN_ANGLE, "... and turn left");
	for (int k = 0; k < 5; k++) tick(0, 0, 0, 0, false);
	{ vc_in_t in = { .now_ms = now += VC_TICK_MS, .motion_done = true, .all_ready = true, .all_alive = true }; vc_step(&v, &in, &o); }
	CHECK(v.state == VC_LINE_FOLLOW && o.motion.type == MOTION_CMD_GO && o.motion.speed_mm_s == VC_BENCH_SPEED, "... then line following again");
	tick(0, 0, &junc, 0, false);
	for (int k = 0; k < VC_JUNCTION_PAUSE_MS / VC_TICK_MS + 2; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && o.motion.type == MOTION_CMD_GO, "the command is used once (next junction: straight on)");
#else
	CHECK(v.state == VC_LINE_FOLLOW && !o.send_motion, "barcodes off: barcode + junction do not turn the bench car");
#endif
	tick(0, &stop, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW, "a STOP barcode does not end the bench run");
	tick(0, 0, &lost, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW, "line lost does not stop it");
	tick(0, 0, 0, &sf, false); tick(0, 0, 0, &hit, false);
	CHECK(v.state == VC_LINE_FOLLOW, "missing IMU (VC_REQUIRE_IMU %d) does not stop it", VC_REQUIRE_IMU);
	for (int k = 0; k < 3000; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW, "still running after 60 s");

	/* ---- obstacle: stop, sweep, hold while it is there, drive on when it has gone ---- */
	tick(0, 0, 0, 0, true);
	CHECK(v.state == VC_OBSTACLE_AVOID && o.send_motion && o.motion.type == MOTION_CMD_STOP && o.scan_request,
	      "obstacle -> STOP and ask the servo for a sweep");
	for (int k = 0; k < 20; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_OBSTACLE_AVOID && !o.send_motion, "stays stopped while the sweep runs");
	obstacle_t ob; memset(&ob, 0, sizeof ob); ob.found = true; ob.distance_mm = 150; ob.width_mm = 100; ob.side = 1;
	g_obst = &ob; tick(0, 0, 0, 0, false); g_obst = 0;
	CHECK(v.state == VC_OBSTACLE_AVOID, "a sweep result alone does not restart it");
	for (int k = 0; k < 100; k++) { tick(0, 0, 0, 0, true); }	/* obstacle still in front */
	CHECK(v.state == VC_OBSTACLE_AVOID && !o.send_motion, "held while the obstacle is still close");
	for (int k = 0; k < VC_BENCH_CLEAR_MS / VC_TICK_MS - 3; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_OBSTACLE_AVOID, "not restarted before it has been clear for %d ms", VC_BENCH_CLEAR_MS);
	for (int k = 0; k < 6; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW, "clear for a while -> back to line following");
	tick(0, 0, 0, 0, false);
	/* no sweep result at all (scan task dead): still holds, still resumes once clear */
	tick(0, 0, 0, 0, true);
	for (int k = 0; k < VC_SCAN_TIMEOUT_MS / VC_TICK_MS + VC_BENCH_CLEAR_MS / VC_TICK_MS + 10; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && v.fault == FAULT_NONE, "no sweep result: no fault, resumes when clear");
	/* a stalled wheel: fault, then an automatic reset and the car drives on */
	g_mfault = true; tick(0, 0, 0, 0, false); g_mfault = false;
	CHECK(v.state == VC_FAULT && v.fault == FAULT_MOTION && o.stop_set, "stalled wheel -> FAULT, motors stopped");
	for (int k = 0; k < VC_BENCH_RETRY_MS / VC_TICK_MS - 2; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_FAULT, "stays stopped for %d ms", VC_BENCH_RETRY_MS);
	bool reset_seen = false;
	for (int k = 0; k < 5; k++) { tick(0, 0, 0, 0, false); if (o.stop_clear_reset) reset_seen = true; }
	CHECK(reset_seen && v.state == VC_IDLE, "then resets the motors");
	for (int k = 0; k < 20; k++) tick(0, 0, 0, 0, false);
	CHECK(v.state == VC_LINE_FOLLOW && v.fault == FAULT_NONE, "and drives on");
	tick(0, 0, 0, 0, true);
	tick(&STOP, 0, 0, 0, false);
	CHECK(v.state == VC_FAULT && o.motion.type == MOTION_CMD_STOP, "a remote STOP still stops it, also during an obstacle");

	printf("%d checks, %d failed\n%s\n", checks, fails, fails ? "FAILED" : "ALL PASSED");
	return fails != 0;
}
