#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "../../../app_program/subsystem3/line_algo.h"
#include "../../../app_program/subsystem3/barcode_algo.h"
#include "../../../app_program/subsystem3/line_config.h"
#include "../../../app_program/subsystem5/vc_msgs.h"
static int fails, checks;
#define CHECK(c, ...) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
#define W 700
#define B 3300

static la_event_t run(la_t *a, int l, int r, int ms, la_out_t *last)
{
	la_event_t ev = LA_NO_EVENT;
	for (int i = 0; i < ms / LINE_PERIOD_MS; i++) {
		la_step(a, l, r, last);
		if (last->event != LA_NO_EVENT) ev = last->event;
	}
	return ev;
}
static void calibrate(la_t *a)
{
	la_out_t o; la_init(a);
	run(a, W, W, 1000, &o); run(a, B, B, 1000 + 10, &o);	/* sees both white and black */
}
/* ---- Code 39 test helpers ---- */
static const char *c39_pat(char c)
{
	switch (c) {
	case '*': return "010010100"; case 'A': return "100001001"; case 'B': return "001001001";
	case 'C': return "101001000"; case 'D': return "000011001"; case 'Z': return "011010000";
	default:  return 0;
	}
}
/* widths (us) for a string like "*A*": narrow n, wide = ratio x n, narrow gap between characters */
static int c39_widths(const char *str, uint32_t n, float ratio, uint32_t *w)
{
	int k = 0;
	for (const char *c = str; *c; c++) {
		const char *pt = c39_pat(*c);
		if (c != str) w[k++] = n;
		for (int i = 0; i < 9; i++) w[k++] = pt[i] == '1' ? (uint32_t)(ratio * (float)n) : n;
	}
	return k;
}
/* drive the decoder with those widths starting at t0, then a long white; returns the result of the read */
static bd_result_t c39_scan(const uint32_t *w, int k, uint32_t t0, bool reverse, bd_read_t *rd)
{
	bd_t b; bd_init(&b);
	uint32_t t = t0;
	bd_result_t r = BD_NONE;
	for (int i = 0; i < k; i++) {
		bd_edge(&b, t, (i % 2) == 0);			/* even elements are bars */
		t += reverse ? w[k - 1 - i] : w[i];
	}
	bd_edge(&b, t, false);					/* end of the last bar */
	for (uint32_t q = 0; q < 10000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, rd);
	return r;
}

int main(void)
{
	la_t a; la_out_t o;

	/* calibration */
	calibrate(&a);
	CHECK(a.state == 1 && a.cal_ok, "calibration ok");
	CHECK(abs(a.white_l - W) <= 1 && abs(a.black_l - B) <= 1, "thresholds %d..%d", a.white_l, a.black_l);
	la_init(&a); run(&a, 1000, 1010, 2100, &o);
	CHECK(a.state == 1 && !a.cal_ok, "flat readings rejected, defaults used");

	/* offset and steering sign */
	calibrate(&a);
	run(&a, W, B, 100, &o);
	CHECK(o.offset > 0.9f && o.on_line, "line under right sensor: offset +%.2f", o.offset);
	CHECK(o.steering_corr < 0, "line on the right -> steer right (negative corr), got %.1f", o.steering_corr);
	run(&a, B, W, 100, &o);
	CHECK(o.offset < -0.9f && o.steering_corr > 0, "line on the left -> steer left (positive corr)");
	run(&a, (W + B) / 2 + 600, (W + B) / 2 + 600, 10, &o);
	CHECK(fabsf(o.offset) < 0.01f, "centred -> offset 0");

	/* junction once, steering zeroed, then re-arms */
	calibrate(&a);
	int junctions = 0;
	for (int i = 0; i < 40; i++) { la_step(&a, B, B, &o); if (o.event == LA_JUNCTION) junctions++; }
	CHECK(junctions == 1 && o.steering_corr == 0.0f, "one JUNCTION per crossing (%d)", junctions);
	run(&a, W, B, 50, &o);
	for (int i = 0; i < 40; i++) { la_step(&a, B, B, &o); if (o.event == LA_JUNCTION) junctions++; }
	CHECK(junctions == 2, "second crossing reported again (%d)", junctions);

#if LINE_STRADDLE
	/* sensors just outside the line: both white is the NORMAL state, never "lost" */
	calibrate(&a);
	la_event_t e = run(&a, W, W, 3000, &o);
	CHECK(e == LA_NO_EVENT && o.on_line && o.steering_corr == 0.0f && fabsf(o.offset) < 0.01f,
	      "both white for 3 s: on course, straight, no LINE_LOST (event %d)", (int)e);
	e = run(&a, B, W, 20, &o);
	CHECK(e == LA_LINE_FOUND, "a sensor reaching the line after a quiet stretch -> LINE_FOUND");
	CHECK(o.steering_corr > 0, "left sensor on black -> steer left (toward it), corr %.1f", o.steering_corr);
	e = run(&a, B, W, 200, &o);
	CHECK(e == LA_NO_EVENT, "LINE_FOUND is rate limited");
	run(&a, W, W, 200, &o);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_NO_EVENT, "second LINE_FOUND held off for %d ms", LINE_FOUND_HOLDOFF_MS);
	run(&a, W, W, LINE_FOUND_HOLDOFF_MS, &o);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_LINE_FOUND && o.steering_corr < 0, "after the hold-off, right sensor -> LINE_FOUND, steer right");
	/* a perpendicular junction line: first one sensor, then both -> JUNCTION still reported */
	calibrate(&a);
	run(&a, W, W, 300, &o);
	run(&a, W, B, 10, &o);
	e = run(&a, B, B, 60, &o);
	CHECK(e == LA_JUNCTION, "junction after one sensor then both black (event %d)", (int)e);
	/* curves: the line only grazes a sensor (30 % black) -> still steer hard, then keep turning while it fades */
	calibrate(&a);
	run(&a, W, W, 400, &o);
	int graze = W + (int)(0.3f * (B - W));
	run(&a, graze, W, 10, &o);
	CHECK(o.steering_corr >= LINE_STEER_MIN, "grazing the left sensor steers at least %d (got %d)", (int)LINE_STEER_MIN, (int)o.steering_corr);
	run(&a, W, graze, 10, &o);
	CHECK(o.steering_corr <= -LINE_STEER_MIN, "grazing the right sensor steers right (got %d)", (int)o.steering_corr);
	run(&a, W, W, 5, &o);
	CHECK(o.steering_corr < -10.0f, "just after the sensor leaves the line the turn is held (got %d)", (int)o.steering_corr);
	float first = o.steering_corr;
	run(&a, W, W, LINE_STEER_HOLD_MS / 2, &o);
	CHECK(o.steering_corr > first && o.steering_corr < 0.0f, "...and fades (%d -> %d)", (int)first, (int)o.steering_corr);
	run(&a, W, W, LINE_STEER_HOLD_MS, &o);
	CHECK(o.steering_corr == 0.0f, "...to zero: drives straight again");
	run(&a, W, B, 30, &o);
	CHECK(o.steering_corr < -150.0f, "fully on the line: strong steer (got %d)", (int)o.steering_corr);
#else
	/* line lost / found */
	calibrate(&a);
	run(&a, B, W, 100, &o);
	la_event_t e = run(&a, W, W, LINE_LOST_MS - 20, &o);
	CHECK(e == LA_NO_EVENT, "not lost too early");
	e = run(&a, W, W, 60, &o);
	CHECK(e == LA_LINE_LOST, "LINE_LOST after %d ms", LINE_LOST_MS);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_LINE_FOUND, "LINE_FOUND when a sensor sees black");
	e = run(&a, W, B, 200, &o);
	CHECK(e == LA_NO_EVENT, "found only once");
#endif

	/* barcode: Code 39 "*A*".."*D*", both directions, slow and fast, wide ratio 2.2 and 3 */
	static const struct { const char *s; int nav; char c; } tab[] = {
		{"*A*", NAV_LEFT, 'A'}, {"*B*", NAV_RIGHT, 'B'}, {"*C*", NAV_STRAIGHT, 'C'}, {"*D*", NAV_UTURN, 'D'} };
	for (int sp = 0; sp < 2; sp++)
		for (int rev = 0; rev < 2; rev++)
			for (unsigned k = 0; k < 4; k++) {
				uint32_t w[64]; bd_read_t rd;
				int n = c39_widths(tab[k].s, sp ? 8000 : 40000, sp ? 3.0f : 2.2f, w);
				bd_result_t r = c39_scan(w, n, 1000, rev, &rd);
				CHECK(r == BD_VALID && rd.nav == tab[k].nav && rd.text[0] == tab[k].c && rd.text[1] == 0 && rd.reversed == (rev != 0),
				      "%s speed %d reverse %d -> \"%s\" nav %d (r=%d, pattern %s)", tab[k].s, sp, rev, rd.text, rd.nav, r, rd.pattern);
			}
	{ uint32_t w[64]; bd_read_t rd;
	  int n = c39_widths("*Z*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'Z' && rd.nav == -1, "a valid letter that is not a command: read, no command"); }
	{ uint32_t w[64]; bd_read_t rd;
	  int n = c39_widths("*AB*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'A' && rd.text[1] == 'B' && rd.nav == NAV_LEFT, "two letters \"%s\"", rd.text); }
	{ uint32_t w[64]; bd_read_t rd;					/* one element lost: does not decode, but is reported */
	  int n = c39_widths("*A*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n - 2, 1000, false, &rd);
	  CHECK(r == BD_INVALID && rd.n_elements == n - 2 && rd.pattern[0] != 0, "damaged code -> INVALID with pattern %s", rd.pattern); }
	{ uint32_t w[64]; bd_read_t rd;					/* speed changes 30 % across the code */
	  int n = c39_widths("*C*", 20000, 2.5f, w);
	  for (int i = 0; i < n; i++) w[i] = w[i] * (100 + i) / 100;
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_STRAIGHT, "speed drifting during the read still decodes (r=%d %s)", r, rd.pattern); }
	{ uint32_t w[64]; bd_read_t rd; bd_t b; bd_init(&b);		/* a 1 ms white glitch inside a wide bar is merged */
	  int n = c39_widths("*B*", 20000, 2.5f, w);
	  uint32_t t = 5000; bd_result_t r = BD_NONE;
	  for (int i = 0; i < n; i++) {
		bd_edge(&b, t, (i % 2) == 0);
		if (i == 1) { bd_edge(&b, t + 5000, true); bd_edge(&b, t + 6000, false); }	/* glitch in a space */
		t += w[i];
	  }
	  bd_edge(&b, t, false);
	  for (uint32_t q = 0; q < 2000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_RIGHT, "glitch merged (r=%d %s)", r, rd.pattern); }
	{ bd_read_t rd; bd_t b; bd_init(&b); bd_result_t r = BD_NONE;	/* the black line under the sensor: not a code */
	  bd_edge(&b, 1000, true);
	  for (uint32_t q = 0; q < 3000000u; q += 1000) if (bd_poll(&b, 1000 + q, &rd) != BD_NONE) r = BD_VALID;
	  bd_edge(&b, 3001000, false);
	  for (uint32_t q = 0; q < 1000000u; q += 1000) if (bd_poll(&b, 3001000 + q, &rd) != BD_NONE) r = BD_VALID;
	  CHECK(r == BD_NONE, "a long black stretch is ignored silently"); }
	{ uint32_t w[64]; bd_read_t rd;					/* clock wrap-around */
	  int n = c39_widths("*D*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 0xFFFFFFFFu - 300000u, false, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_UTURN, "timestamps wrap around cleanly"); }

	{ bd_read_t rd; bd_t b; bd_init(&b); bd_result_t r = BD_NONE;	/* what the robot saw on 11 Nov: a long white gap ends the read */
	  uint32_t t = 1000, el[] = { 159000, 280000, 200000 };
	  for (int i = 0; i < 3; i++) { bd_edge(&b, t, (i % 2) == 0); t += el[i]; }
	  bd_edge(&b, t, false);
	  uint32_t q;
	  for (q = 0; q < 3000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(r == BD_INVALID && rd.n_elements == 3, "3 stripes then a long gap -> reported as NOT decoded (r=%d after %u ms)", r, q / 1000); }
	{ /* the course barcode as the robot really saw it on 11 Nov 18:48 (stripe ms, peak adc): blurred, thin bars
	     only ~300, first bar a slow 1 s rise. Decoded by bar darkness + bar-centre spacing. */
	  static const int el[][2] = { {1059,306},{619,206},{180,359},{280,240},{379,2653},{540,239},{339,2559},{601,214},
		{179,326},{320,220},{179,301},{219,217},{299,2596},{620,216},{359,2531},{1060,189},{280,298},{199,221},{140,310},
		{359,213},{120,292},{719,184},{200,294},{259,203},{339,2392},{540,207},{379,2349},{560,199},{120,313} };
	  bd_t b; bd_init(&b); bd_read_t rd; bd_result_t r = BD_NONE;
	  uint32_t t = 5000000;
	  bd_edge_p(&b, t, true, 200);
	  for (unsigned i = 0; i < sizeof el / sizeof el[0]; i++) { t += (uint32_t)el[i][0] * 1000u; bd_edge_p(&b, t, (i % 2) == 1, el[i][1]); }
	  for (uint32_t q = 0; q < 3000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'F' && rd.text[1] == 0 && rd.n_elements == 29, "real log decodes as \"%s\" (r=%d, %d elements, %s)", rd.text, r, rd.n_elements, rd.pattern); }
	{ /* and backwards (the car driving the other way over it) */
	  static const int el[][2] = { {120,313},{560,199},{379,2349},{540,207},{339,2392},{259,203},{200,294},{719,184},{120,292},
		{359,213},{140,310},{199,221},{280,298},{1060,189},{359,2531},{620,216},{299,2596},{219,217},{179,301},{320,220},
		{179,326},{601,214},{339,2559},{540,239},{379,2653},{280,240},{180,359},{619,206},{200,306} };
	  bd_t b; bd_init(&b); bd_read_t rd; bd_result_t r = BD_NONE;
	  uint32_t t = 5000000;
	  bd_edge_p(&b, t, true, 200);
	  for (unsigned i = 0; i < sizeof el / sizeof el[0]; i++) { t += (uint32_t)el[i][0] * 1000u; bd_edge_p(&b, t, (i % 2) == 1, el[i][1]); }
	  for (uint32_t q = 0; q < 3000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'F' && rd.reversed, "real log backwards decodes as \"%s\" reversed=%d", rd.text, rd.reversed); }

	{ /* 11 Nov 18:58, a different barcode, driven over backwards: 31 stripes, one of them a shallow dip (99 ms, never
	     lighter than 2173) that split a thick bar. Merged back -> 29 -> decoded. */
	  static const int el[][2] = { {159,315},{340,206},{359,2558},{540,202},{399,2612},{540,205},{119,321},{799,184},
		{280,291},{159,210},{319,2763},{619,212},{160,305},{739,184},{160,307},{339,199},{180,305},{239,209},{299,2774},
		{640,211},{139,311},{320,213},{319,2645},{580,213},{320,2775},{99,2173},{80,2364},{479,211},{160,293},{760,184},{200,295} };
	  bd_t b; bd_init(&b); bd_read_t rd; bd_result_t r = BD_NONE;
	  uint32_t t = 5000000;
	  bd_edge_p(&b, t, true, 200);
	  for (unsigned i = 0; i < sizeof el / sizeof el[0]; i++) { t += (uint32_t)el[i][0] * 1000u; bd_edge_p(&b, t, (i % 2) == 1, el[i][1]); }
	  for (uint32_t q = 0; q < 3000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  printf("  18:58 barcode -> r=%d \"%s\" reversed=%d nav=%d pattern %s\n", r, rd.text, rd.reversed, rd.nav, rd.pattern);
	  CHECK(r == BD_VALID && rd.text[0] && rd.reversed, "18:58 barcode decodes (backwards)"); }

	{ /* no barcode size is assumed: narrow 1.5..15 mm, wide 2-3 x narrow, 50..200 mm/s, both directions */
	  static const float narrow_mm[] = { 1.5f, 3.0f, 6.0f, 10.0f, 15.0f }, ratio[] = { 2.0f, 2.5f, 3.0f }, speed[] = { 50.0f, 90.0f, 200.0f };
	  static const char *codes[] = { "*A*", "*B*", "*C*", "*D*", "*Z*" };
	  int bad = 0, total = 0;
	  for (unsigned a = 0; a < 5; a++) for (unsigned r = 0; r < 3; r++) for (unsigned v = 0; v < 3; v++) for (int rev = 0; rev < 2; rev++) {
		uint32_t w[64]; bd_read_t rd;
		uint32_t n_us = (uint32_t)(narrow_mm[a] / speed[v] * 1e6f);
		int n = c39_widths(codes[(a + r + v) % 5], n_us, ratio[r], w);
		bd_result_t res = c39_scan(w, n, 1000, rev, &rd);
		total++;
		if (res != BD_VALID || rd.text[0] != codes[(a + r + v) % 5][1]) {
			bad++;
			printf("  size %.1f mm ratio %.1f speed %.0f rev %d: r=%d \"%s\"\n", narrow_mm[a], ratio[r], speed[v], rev, res, rd.text);
		}
	  }
	  CHECK(bad == 0, "%d of %d sizes/speeds failed", bad, total); }

	{ /* 11 Nov 19:16: a bar, a long (939 ms) space, then more bars: must stay ONE read, not end after the first bar */
	  bd_t b; bd_init(&b); bd_read_t rd; bd_result_t r = BD_NONE; int reads = 0;
	  static const int el[][2] = { {200,1845},{939,187},{239,1818},{280,226},{160,2007} };
	  uint32_t t = 5000000;
	  bd_edge_p(&b, t, true, 200);
	  for (unsigned i = 0; i < 5; i++) {
		for (uint32_t q = 1000; q < (uint32_t)el[i][0] * 1000u; q += 1000) if (bd_poll(&b, t + q, &rd) != BD_NONE) reads++;
		t += (uint32_t)el[i][0] * 1000u; bd_edge_p(&b, t, (i % 2) == 1, el[i][1]);
	  }
	  for (uint32_t q = 0; q < 5000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(reads == 0 && r == BD_INVALID && rd.n_elements == 5, "kept as one read of 5 stripes (early ends %d, n=%d)", reads, rd.n_elements); }

	{ /* 11 Nov 19:24: thin bars (~120-220 ms) with blurred wide spaces up to 720 ms: the read must not end after the
	     first three stripes (it did: 4 x 119 ms < the 699 ms space that followed) */
	  static const int el[][2] = { {140,2757},{480,199},{119,308},{699,180},{220,288},{219,184},{379,2765},{640,209},
		{200,299},{679,189},{200,307},{299,197},{140,295},{201,196},{339,2679},{599,202},{180,297},{279,207},{400,2579},
		{540,205},{300,2837},{119,2244},{59,2379},{500,204},{179,293},{720,173},{199,287} };
	  bd_t b; bd_init(&b); bd_read_t rd; int early = 0;
	  uint32_t t = 5000000;
	  bd_edge_p(&b, t, true, 200);
	  for (unsigned i = 0; i < sizeof el / sizeof el[0]; i++) {
		for (uint32_t q = 1000; q < (uint32_t)el[i][0] * 1000u; q += 1000) if (bd_poll(&b, t + q, &rd) != BD_NONE) early++;
		t += (uint32_t)el[i][0] * 1000u; bd_edge_p(&b, t, (i % 2) == 1, el[i][1]);
	  }
	  CHECK(early == 0 && b.active && b.n == 27, "19:24 stripes stay one read (ended early %d times, n=%d)", early, b.n);
	  /* ... and the junction 0.5 s later ends it there (it used to be blanked as "a barcode bar" and missed) */
	  bd_result_t r = bd_finish(&b, &rd);
	  CHECK(r == BD_INVALID && !b.active && rd.n_elements == 27, "19:24 at the junction: read closed (r=%d n=%d)", r, rd.n_elements);
	  CHECK(bd_finish(&b, &rd) == BD_NONE, "a second finish with no open read does nothing"); }

	{ /* junction straight after a clean "*B*" (before the quiet zone ended the read): decoded at the junction */
	  uint32_t w[64]; int n = c39_widths("*B*", 30000, 3.0f, w);
	  bd_t b; bd_init(&b); bd_read_t rd; uint32_t t = 2000000;
	  for (int i = 0; i < n; i++) { bd_edge(&b, t, (i % 2) == 0); t += w[i]; }
	  bd_edge(&b, t, false);
	  bd_result_t r = bd_finish(&b, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'B' && rd.nav == NAV_RIGHT, "junction right after *B*: RIGHT (r=%d '%s')", r, rd.text);

	  /* the junction's own line also crosses the barcode sensor: one extra bar after a gap */
	  bd_init(&b); t = 2000000;
	  for (int i = 0; i < n; i++) { bd_edge(&b, t, (i % 2) == 0); t += w[i]; }
	  bd_edge(&b, t, false); t += 100000;			/* 100 ms of white */
	  bd_edge(&b, t, true);  t += 60000;			/* junction line under the barcode sensor */
	  bd_edge(&b, t, false);
	  r = bd_finish(&b, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_RIGHT, "... with the junction line as an extra bar: still RIGHT (r=%d)", r);

	  /* finished while the barcode sensor is still on that junction line */
	  bd_init(&b); t = 2000000;
	  for (int i = 0; i < n; i++) { bd_edge(&b, t, (i % 2) == 0); t += w[i]; }
	  bd_edge(&b, t, false); t += 100000;
	  bd_edge(&b, t, true);
	  r = bd_finish(&b, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_RIGHT, "... finished while on the junction line: still RIGHT (r=%d)", r); }

	printf("%d checks, %d failed\n", checks, fails);
	printf(fails ? "SOME FAILED\n" : "ALL PASSED\n");
	return fails != 0;
}
