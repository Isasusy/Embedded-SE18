/*
 *	barcode_algo.h / barcode_algo.c -- Barcode Decoder logic (statechart 6.1: BARCODE_SCAN, DECODED).
 *	Fed with timestamped edges of IR3 (GP28). No kernel or hardware calls.
 */
#ifndef BARCODE_ALGO_H
#define BARCODE_ALGO_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
	bool		active;
	bool		in_bar;
	int		bars;			/* completed bars */
	uint32_t	t_rise_us, last_edge_us;
	uint32_t	width_us[8];
} bd_t;

typedef enum { BD_NONE, BD_VALID, BD_INVALID } bd_result_t;

void		bd_init(bd_t *b);
/* feed one edge; `black` = true when the level after the edge is black. On BD_VALID, *nav_cmd / *code are set. */
bd_result_t	bd_edge(bd_t *b, uint32_t t_us, bool black, int *nav_cmd, int *code);
/* call periodically: discards a half-read code that went quiet (BD_INVALID once) */
bd_result_t	bd_poll(bd_t *b, uint32_t now_us);

#endif
