#include "subsystem3.h"
#include <bsp/libbsp.h>
#include "../../device/include/dev_adc.h"	/* dev_init_adc */
#include "drv_line.h"
#include "line_config.h"
#include "s3_port.h"

static ID	s_dd = 0;			/* descriptor of "adca" */

static ID open_adc(void)
{
	ID dd = tk_opn_dev((UB *)"adca", TD_READ);
	if (dd < E_OK) {			/* not registered yet: register it, then open again */
		dev_init_adc(0);
		dd = tk_opn_dev((UB *)"adca", TD_READ);
	}
	return dd;
}

bool line_adc_init(void)
{
	ID dd = open_adc();

	if (dd < E_OK) {
		S3_PRINTF("[S3] ADC device 'adca' not available (err %d): line sensors will read 0\n", (int)dd);
		return false;
	}
	s_dd = dd;
	return true;
}

/* The kernel's RP2040 ADC driver converts exactly ONE sample per call: start = channel, size = 1,
   and it stores the 12-bit result in a 32-bit word. */
static int adc_ch(int ch)
{
	UW buf = 0;
	SZ asz = 0;
	static int s_errs;

	if (s_dd <= 0) return 0;
	if (tk_srea_dev(s_dd, ch, &buf, 1, &asz) < E_OK) {
		if (s_errs++ < 3) S3_PRINTF("[S3] ADC read of channel %d failed\n", ch);
		return 0;
	}
	return (int)(buf & 0x0FFFu);
}

void line_adc_read(int *left, int *right)
{
	*left  = adc_ch(0);			/* GP26 = ADC0 */
	*right = adc_ch(1);			/* GP27 = ADC1 */
}

/* ---- barcode: polled edge recorder ---- */
#define RING	64u				/* power of two */
static bar_edge_t	s_ring[RING];
static unsigned		s_head, s_tail, s_over;
static int		s_last = -1;

void barcode_init(void)
{
	gpio_set_pin(PIN_BARCODE, GPIO_MODE_IN);
	s_last = -1;
}

void barcode_sample(void)
{
	uint32_t t = S3_US32();
	int level = gpio_get_val(PIN_BARCODE) ? 1 : 0;

	if (s_last < 0) { s_last = level; return; }
	if (level == s_last) return;
	s_last = level;
	if (s_head - s_tail >= RING) { s_over++; return; }
	s_ring[s_head % RING].t_us  = t;
	s_ring[s_head % RING].black = (level == (BARCODE_BLACK_IS_HIGH ? 1 : 0));
	s_head++;
}

bool barcode_edge_pop(bar_edge_t *e)
{
	if (s_tail == s_head) return false;
	*e = s_ring[s_tail % RING];
	s_tail++;
	return true;
}

unsigned barcode_edge_overruns(void) { return s_over; }
