/*
 *	drv_scan.h / drv_scan.c -- Obstacle Scan hardware, called ONLY from scan_task.
 *	Servo SG90 signal on GP15 (PWM 50 Hz, slice 7 channel B, 5 V supply).
 *	Ultrasonic HC-SR04: TRIG GP17 (output), ECHO GP16 (input, timed).
 *	Pins follow the Fritzing wiring diagram. If the real wires differ, change only these three numbers.
 */
#ifndef DRV_SCAN_H
#define DRV_SCAN_H

#define PIN_SERVO	15
#define PIN_US_TRIG	17
#define PIN_US_ECHO	16

void	servo_init(void);
void	servo_set_deg(int deg);		/* -90 .. +90, + = left, 0 = straight ahead */
void	ultra_init(void);
int	ultra_ping_mm(void);		/* distance in mm, or -1 for no echo; blocks up to ~25 ms */

#endif
