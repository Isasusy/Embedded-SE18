/*
 *	barcode_task.c -- Barcode Decoder. Owns GP28, sampled by polling every 1 ms (no interrupt).
 *	Edge times are therefore quantised to about 1 ms, which is why BAR_MIN_US is 3000.
 *	APIs shown: tk_dly_tsk, tk_snd_mbf
 */
#include "subsystem3.h"
#include "drv_line.h"
#include "barcode_algo.h"
#include "line_config.h"
#include "s3_port.h"

void barcode_task(INT stacd, void *exinf)
{
	bd_t b;
	bar_edge_t e;
	(void)stacd; (void)exinf;

	bd_init(&b);
	barcode_init();

	for (;;) {
		int nav = 0, code = 0;
		bd_result_t r;

		barcode_sample();
		while (barcode_edge_pop(&e)) {
			r = bd_edge(&b, e.t_us, e.black, &nav, &code);
			if (r == BD_VALID) {
				nav_cmd_t m = { nav, code, s3_now_ms() };
				if (mbf_nav_cmd > 0)
					tk_snd_mbf(mbf_nav_cmd, &m, sizeof m, TMO_POL);
#if S3_DEBUG_PRINT
				else
					S3_PRINTF("[S3] >> BARCODE code=%d nav=%d\n", code, nav);
#endif
			} else if (r == BD_INVALID) {
#if S3_DEBUG_PRINT
				S3_PRINTF("[S3] barcode discarded (bad width or code)\n");
#endif
			}
		}
		if (bd_poll(&b, S3_US32()) == BD_INVALID) {
#if S3_DEBUG_PRINT
			S3_PRINTF("[S3] barcode read timed out\n");
#endif
		}
		tk_dly_tsk(1);
	}
}
