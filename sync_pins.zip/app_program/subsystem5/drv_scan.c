/*
 *	drv_scan.c -- servo (PWM) and ultrasonic (GPIO) through the kernel board library. No Pico SDK.
 *	GP15 is PWM slice 7, channel B (any pin works: the slice is computed from the pin number). libbsp has no clock-divider call, so the divider register is written directly.
 */
#include "subsystem5.h"
#include <bsp/libbsp.h>
#include "drv_scan.h"
#include "vc_config.h"
#include "s5_port.h"

#define SERVO_WRAP	62499u			/* (125 MHz / 40) / 62500 = 50 Hz */
#define PWM_DIV_REG(slice)	(*(volatile unsigned int *)(0x40050000u + 0x14u * (slice) + 0x04u))

static void pwm_unreset(void)			/* RESETS.RESET bit 14 = PWM; harmless if already released */
{
	volatile unsigned int *rst  = (volatile unsigned int *)0x4000C000u;
	volatile unsigned int *done = (volatile unsigned int *)0x4000C008u;
	*rst &= ~(1u << 14);
	while (!(*done & (1u << 14))) { }
}

void servo_init(void)
{
	pwm_unreset();
	pwm_set_pin(PIN_SERVO);
	PWM_DIV_REG((PIN_SERVO >> 1) & 7u) = 40u << 4;		/* DIV is 8.4 fixed point: 40.0 */
	pwm_set_wrap(PIN_SERVO, SERVO_WRAP);
	pwm_set_cc(PIN_SERVO, 0);
	pwm_set_enabled(PIN_SERVO, TRUE);
	servo_set_deg(0);
}

void servo_set_deg(int deg)
{
	deg += SERVO_TRIM_DEG;
	if (deg < -90) deg = -90;
	if (deg > 90) deg = 90;
	/* -90 deg -> SERVO_US_MIN, +90 deg -> SERVO_US_MAX. Mounted so that + is the robot's left; flip here if not. */
	unsigned us = SERVO_US_MIN + (unsigned)((deg + 90) * (SERVO_US_MAX - SERVO_US_MIN) / 180);
	pwm_set_cc(PIN_SERVO, (us * 3125u) / 1000u);		/* 3.125 ticks per microsecond */
}

void ultra_init(void)
{
	gpio_set_pin(PIN_US_TRIG, GPIO_MODE_OUT); gpio_set_val(PIN_US_TRIG, 0);
	gpio_set_pin(PIN_US_ECHO, GPIO_MODE_IN);
}

static void wait_us(uint32_t us)
{
	uint32_t t0 = S5_US32();
	while ((uint32_t)(S5_US32() - t0) < us) { }
}

int ultra_ping_mm(void)
{
	gpio_set_val(PIN_US_TRIG, 1);
	wait_us(12);
	gpio_set_val(PIN_US_TRIG, 0);

	uint32_t t0 = S5_US32();
	while (!gpio_get_val(PIN_US_ECHO))			/* wait for the echo pulse to start */
		if ((uint32_t)(S5_US32() - t0) > 6000u) return -1;
	uint32_t t1 = S5_US32();
	while (gpio_get_val(PIN_US_ECHO))			/* ... and end (25 ms = about 4 m) */
		if ((uint32_t)(S5_US32() - t1) > 25000u) return -1;
	uint32_t us = S5_US32() - t1;
	return (int)(us * 343u / 2000u);			/* 0.343 mm/us, there and back */
}
