/*
 *	scan_task.c -- Obstacle Scan. Owns the servo (GP15) and the ultrasonic sensor (TRIG GP17 / ECHO GP16).
 *	WATCH: ping straight ahead every 60 ms. Two close readings in a row set FLG_SCAN_CLOSE.
 *	On FLG_SCAN_REQUEST from the Vehicle Controller: sweep the servo, build the profile, send obstacle_t.
 *	APIs shown: tk_dly_tsk, tk_set_flg, tk_wai_flg (polling), tk_clr_flg, tk_snd_mbf
 */
#include "subsystem5.h"
#include "drv_scan.h"
#include "scan_algo.h"
#include "vc_config.h"
#include "s5_port.h"

static int ping_median3(void)
{
	int a = ultra_ping_mm(); tk_dly_tsk(2);
	int b = ultra_ping_mm(); tk_dly_tsk(2);
	int c = ultra_ping_mm();
	/* median of three; -1 (no echo) sorts lowest, so treat two no-echoes as no echo */
	if (a > b) { int t = a; a = b; b = t; }
	if (b > c) { int t = b; b = c; c = t; }
	if (a > b) { int t = a; a = b; b = t; }
	return b;
}

static void do_sweep(void)
{
	int ang[SCAN_MAX_RAYS], dist[SCAN_MAX_RAYS], n = 0;
	obstacle_t ob;

	for (int a = -SCAN_ANGLE_MAX; a <= SCAN_ANGLE_MAX && n < SCAN_MAX_RAYS; a += SCAN_ANGLE_STEP) {
		servo_set_deg(a);
		tk_dly_tsk(SCAN_SETTLE_MS);
		ang[n] = a;
		dist[n] = ping_median3();
		n++;
	}
	servo_set_deg(0);
	scan_analyze(ang, dist, n, &ob);
#if S5_DEBUG_PRINT
	S5_PRINTF("[S5] scan: found=%d dist=%d width=%d left=%d right=%d side=%d\n", ob.found, (int)ob.distance_mm,
		  (int)ob.width_mm, (int)ob.left_clear_mm, (int)ob.right_clear_mm, (int)ob.side);
#endif
	tk_snd_mbf(mbf_obstacle, &ob, sizeof ob, TMO_POL);
}

void scan_task(INT stacd, void *exinf)
{
	int close_count = 0;
	(void)stacd; (void)exinf;

	servo_init();
	ultra_init();
	tk_dly_tsk(300);			/* let the servo reach 0 */

	for (;;) {
		UINT ptn;
		if (tk_wai_flg(flg_scan, FLG_SCAN_REQUEST, TWF_ORW | TWF_BITCLR, &ptn, TMO_POL) == E_OK) {
			do_sweep();
			close_count = 0;
			tk_clr_flg(flg_scan, ~(UINT)FLG_SCAN_CLOSE);
		} else {
			int d = ultra_ping_mm();
			close_count = (d > 0 && d < SCAN_CLOSE_MM) ? close_count + 1 : 0;
			if (close_count >= 2)
				tk_set_flg(flg_scan, FLG_SCAN_CLOSE);
		}
		tk_dly_tsk(SCAN_PERIOD_MS);
	}
}
