/*
 *	enc_task.c -- Subsystem 2: polls the four wheel-encoder pins every 1 ms (replaces a GPIO interrupt).
 *	APIs shown: tk_dly_tsk
 */
#include "subsystem2.h"
#include "drv_encoder.h"

void enc_task(INT stacd, void *exinf)
{
	(void)stacd; (void)exinf;

	enc_init();
	for (;;) {
		enc_poll();
		tk_dly_tsk(1);
	}
}
