#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "../../../app_program/subsystem3/line_algo.h"
#include "../../../app_program/subsystem3/barcode_algo.h"
#include "../../../app_program/subsystem3/line_config.h"
#include "../../../app_program/subsystem5/vc_msgs.h"
static int fails, checks;
#define CHECK(c, ...) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
#define W 700
#define B 3300

static la_event_t run(la_t *a, int l, int r, int ms, la_out_t *last)
{
	la_event_t ev = LA_NO_EVENT;
	for (int i = 0; i < ms / LINE_PERIOD_MS; i++) {
		la_step(a, l, r, last);
		if (last->event != LA_NO_EVENT) ev = last->event;
	}
	return ev;
}
static void calibrate(la_t *a)
{
	la_out_t o; la_init(a);
	run(a, W, W, 1000, &o); run(a, B, B, 1000 + 10, &o);	/* sees both white and black */
}
/* ---- Code 39 test helpers ---- */
static const char *c39_pat(char c)
{
	switch (c) {
	case '*': return "010010100"; case 'A': return "100001001"; case 'B': return "001001001";
	case 'C': return "101001000"; case 'D': return "000011001"; case 'Z': return "011010000";
	default:  return 0;
	}
}
/* widths (us) for a string like "*A*": narrow n, wide = ratio x n, narrow gap between characters */
static int c39_widths(const char *str, uint32_t n, float ratio, uint32_t *w)
{
	int k = 0;
	for (const char *c = str; *c; c++) {
		const char *pt = c39_pat(*c);
		if (c != str) w[k++] = n;
		for (int i = 0; i < 9; i++) w[k++] = pt[i] == '1' ? (uint32_t)(ratio * (float)n) : n;
	}
	return k;
}
/* drive the decoder with those widths starting at t0, then a long white; returns the result of the read */
static bd_result_t c39_scan(const uint32_t *w, int k, uint32_t t0, bool reverse, bd_read_t *rd)
{
	bd_t b; bd_init(&b);
	uint32_t t = t0;
	bd_result_t r = BD_NONE;
	for (int i = 0; i < k; i++) {
		bd_edge(&b, t, (i % 2) == 0);			/* even elements are bars */
		t += reverse ? w[k - 1 - i] : w[i];
	}
	bd_edge(&b, t, false);					/* end of the last bar */
	for (uint32_t q = 0; q < 2000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, rd);
	return r;
}

int main(void)
{
	la_t a; la_out_t o;

	/* calibration */
	calibrate(&a);
	CHECK(a.state == 1 && a.cal_ok, "calibration ok");
	CHECK(abs(a.white_l - W) <= 1 && abs(a.black_l - B) <= 1, "thresholds %d..%d", a.white_l, a.black_l);
	la_init(&a); run(&a, 1000, 1010, 2100, &o);
	CHECK(a.state == 1 && !a.cal_ok, "flat readings rejected, defaults used");

	/* offset and steering sign */
	calibrate(&a);
	run(&a, W, B, 100, &o);
	CHECK(o.offset > 0.9f && o.on_line, "line under right sensor: offset +%.2f", o.offset);
	CHECK(o.steering_corr < 0, "line on the right -> steer right (negative corr), got %.1f", o.steering_corr);
	run(&a, B, W, 100, &o);
	CHECK(o.offset < -0.9f && o.steering_corr > 0, "line on the left -> steer left (positive corr)");
	run(&a, (W + B) / 2 + 600, (W + B) / 2 + 600, 10, &o);
	CHECK(fabsf(o.offset) < 0.01f, "centred -> offset 0");

	/* junction once, steering zeroed, then re-arms */
	calibrate(&a);
	int junctions = 0;
	for (int i = 0; i < 40; i++) { la_step(&a, B, B, &o); if (o.event == LA_JUNCTION) junctions++; }
	CHECK(junctions == 1 && o.steering_corr == 0.0f, "one JUNCTION per crossing (%d)", junctions);
	run(&a, W, B, 50, &o);
	for (int i = 0; i < 40; i++) { la_step(&a, B, B, &o); if (o.event == LA_JUNCTION) junctions++; }
	CHECK(junctions == 2, "second crossing reported again (%d)", junctions);

#if LINE_STRADDLE
	/* sensors just outside the line: both white is the NORMAL state, never "lost" */
	calibrate(&a);
	la_event_t e = run(&a, W, W, 3000, &o);
	CHECK(e == LA_NO_EVENT && o.on_line && o.steering_corr == 0.0f && fabsf(o.offset) < 0.01f,
	      "both white for 3 s: on course, straight, no LINE_LOST (event %d)", (int)e);
	e = run(&a, B, W, 20, &o);
	CHECK(e == LA_LINE_FOUND, "a sensor reaching the line after a quiet stretch -> LINE_FOUND");
	CHECK(o.steering_corr > 0, "left sensor on black -> steer left (toward it), corr %.1f", o.steering_corr);
	e = run(&a, B, W, 200, &o);
	CHECK(e == LA_NO_EVENT, "LINE_FOUND is rate limited");
	run(&a, W, W, 200, &o);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_NO_EVENT, "second LINE_FOUND held off for %d ms", LINE_FOUND_HOLDOFF_MS);
	run(&a, W, W, LINE_FOUND_HOLDOFF_MS, &o);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_LINE_FOUND && o.steering_corr < 0, "after the hold-off, right sensor -> LINE_FOUND, steer right");
	/* a perpendicular junction line: first one sensor, then both -> JUNCTION still reported */
	calibrate(&a);
	run(&a, W, W, 300, &o);
	run(&a, W, B, 10, &o);
	e = run(&a, B, B, 60, &o);
	CHECK(e == LA_JUNCTION, "junction after one sensor then both black (event %d)", (int)e);
	/* curves: the line only grazes a sensor (30 % black) -> still steer hard, then keep turning while it fades */
	calibrate(&a);
	run(&a, W, W, 400, &o);
	int graze = W + (int)(0.3f * (B - W));
	run(&a, graze, W, 10, &o);
	CHECK(o.steering_corr >= LINE_STEER_MIN, "grazing the left sensor steers at least %d (got %d)", (int)LINE_STEER_MIN, (int)o.steering_corr);
	run(&a, W, graze, 10, &o);
	CHECK(o.steering_corr <= -LINE_STEER_MIN, "grazing the right sensor steers right (got %d)", (int)o.steering_corr);
	run(&a, W, W, 5, &o);
	CHECK(o.steering_corr < -10.0f, "just after the sensor leaves the line the turn is held (got %d)", (int)o.steering_corr);
	float first = o.steering_corr;
	run(&a, W, W, LINE_STEER_HOLD_MS / 2, &o);
	CHECK(o.steering_corr > first && o.steering_corr < 0.0f, "...and fades (%d -> %d)", (int)first, (int)o.steering_corr);
	run(&a, W, W, LINE_STEER_HOLD_MS, &o);
	CHECK(o.steering_corr == 0.0f, "...to zero: drives straight again");
	run(&a, W, B, 30, &o);
	CHECK(o.steering_corr < -150.0f, "fully on the line: strong steer (got %d)", (int)o.steering_corr);
#else
	/* line lost / found */
	calibrate(&a);
	run(&a, B, W, 100, &o);
	la_event_t e = run(&a, W, W, LINE_LOST_MS - 20, &o);
	CHECK(e == LA_NO_EVENT, "not lost too early");
	e = run(&a, W, W, 60, &o);
	CHECK(e == LA_LINE_LOST, "LINE_LOST after %d ms", LINE_LOST_MS);
	e = run(&a, W, B, 20, &o);
	CHECK(e == LA_LINE_FOUND, "LINE_FOUND when a sensor sees black");
	e = run(&a, W, B, 200, &o);
	CHECK(e == LA_NO_EVENT, "found only once");
#endif

	/* barcode: Code 39 "*A*".."*D*", both directions, slow and fast, wide ratio 2.2 and 3 */
	static const struct { const char *s; int nav; char c; } tab[] = {
		{"*A*", NAV_LEFT, 'A'}, {"*B*", NAV_RIGHT, 'B'}, {"*C*", NAV_STRAIGHT, 'C'}, {"*D*", NAV_UTURN, 'D'} };
	for (int sp = 0; sp < 2; sp++)
		for (int rev = 0; rev < 2; rev++)
			for (unsigned k = 0; k < 4; k++) {
				uint32_t w[64]; bd_read_t rd;
				int n = c39_widths(tab[k].s, sp ? 8000 : 40000, sp ? 3.0f : 2.2f, w);
				bd_result_t r = c39_scan(w, n, 1000, rev, &rd);
				CHECK(r == BD_VALID && rd.nav == tab[k].nav && rd.text[0] == tab[k].c && rd.text[1] == 0 && rd.reversed == (rev != 0),
				      "%s speed %d reverse %d -> \"%s\" nav %d (r=%d, pattern %s)", tab[k].s, sp, rev, rd.text, rd.nav, r, rd.pattern);
			}
	{ uint32_t w[64]; bd_read_t rd;
	  int n = c39_widths("*Z*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'Z' && rd.nav == -1, "a valid letter that is not a command: read, no command"); }
	{ uint32_t w[64]; bd_read_t rd;
	  int n = c39_widths("*AB*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.text[0] == 'A' && rd.text[1] == 'B' && rd.nav == NAV_LEFT, "two letters \"%s\"", rd.text); }
	{ uint32_t w[64]; bd_read_t rd;					/* one element lost: does not decode, but is reported */
	  int n = c39_widths("*A*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n - 2, 1000, false, &rd);
	  CHECK(r == BD_INVALID && rd.n_elements == n - 2 && rd.pattern[0] != 0, "damaged code -> INVALID with pattern %s", rd.pattern); }
	{ uint32_t w[64]; bd_read_t rd;					/* speed changes 30 % across the code */
	  int n = c39_widths("*C*", 20000, 2.5f, w);
	  for (int i = 0; i < n; i++) w[i] = w[i] * (100 + i) / 100;
	  bd_result_t r = c39_scan(w, n, 1000, false, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_STRAIGHT, "speed drifting during the read still decodes (r=%d %s)", r, rd.pattern); }
	{ uint32_t w[64]; bd_read_t rd; bd_t b; bd_init(&b);		/* a 1 ms white glitch inside a wide bar is merged */
	  int n = c39_widths("*B*", 20000, 2.5f, w);
	  uint32_t t = 5000; bd_result_t r = BD_NONE;
	  for (int i = 0; i < n; i++) {
		bd_edge(&b, t, (i % 2) == 0);
		if (i == 1) { bd_edge(&b, t + 5000, true); bd_edge(&b, t + 6000, false); }	/* glitch in a space */
		t += w[i];
	  }
	  bd_edge(&b, t, false);
	  for (uint32_t q = 0; q < 2000000u && r == BD_NONE; q += 1000) r = bd_poll(&b, t + q, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_RIGHT, "glitch merged (r=%d %s)", r, rd.pattern); }
	{ bd_read_t rd; bd_t b; bd_init(&b); bd_result_t r = BD_NONE;	/* the black line under the sensor: not a code */
	  bd_edge(&b, 1000, true);
	  for (uint32_t q = 0; q < 3000000u; q += 1000) if (bd_poll(&b, 1000 + q, &rd) != BD_NONE) r = BD_VALID;
	  bd_edge(&b, 3001000, false);
	  for (uint32_t q = 0; q < 1000000u; q += 1000) if (bd_poll(&b, 3001000 + q, &rd) != BD_NONE) r = BD_VALID;
	  CHECK(r == BD_NONE, "a long black stretch is ignored silently"); }
	{ uint32_t w[64]; bd_read_t rd;					/* clock wrap-around */
	  int n = c39_widths("*D*", 20000, 2.5f, w);
	  bd_result_t r = c39_scan(w, n, 0xFFFFFFFFu - 300000u, false, &rd);
	  CHECK(r == BD_VALID && rd.nav == NAV_UTURN, "timestamps wrap around cleanly"); }

	printf("%d checks, %d failed\n", checks, fails);
	printf(fails ? "SOME FAILED\n" : "ALL PASSED\n");
	return fails != 0;
}
