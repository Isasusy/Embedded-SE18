# Shared configuration edits (agree these with the team / instructor)

The drivers use the kernel's own device drivers, which are configured in files the whole team shares.
Pins follow the Fritzing wiring diagram.

## 1. I2C0 pins for the IMU (Subsystem 4): GP0 = SDA, GP1 = SCL
File: `device/i2c/sysdepend/rp2040/i2c_cnf_sysdep.h`

    #define DEVCNF_I2C0_SDA_PIN   0       /* was 8: GP8/GP9 are the left motor, must NOT be claimed by I2C */
    #define DEVCNF_I2C0_SCL_PIN   1       /* was 9 */
    #define DEVCNF_I2C1_SDA_PIN   6       /* leave at the original values: 14/15 would claim GP15 (servo) */
    #define DEVCNF_I2C1_SCL_PIN   7

## 2. ADC pins for the line sensors (Subsystem 3)
File: `device/adc/sysdepend/rp2040/adc_cnf_sysdep.h`

    #define DEVCONF_ADC_PIN_INIT_0   TRUE     /* GP26, left line sensor  */
    #define DEVCONF_ADC_PIN_INIT_1   TRUE     /* GP27, right line sensor */

Leave `_2` (GP28) FALSE (barcode is read as a digital input) and `_3` FALSE (GP29 is the Pico W radio clock).

## 3. Enable the I2C device driver
File: `config/config_device.h`

    #define DEVCNF_USE_IIC   1

## Notes
* GP0/GP1 are also the crash-report UART: do not build with `CRASH_REPORT=1` while the IMU is connected.
* The PWM block is released from reset by `motor_init()` / `servo_init()` (harmless if the kernel already did it).
* The hardware watchdog (only if `VC_WATCHDOG_ENABLE 1`) is programmed by register in `subsystem5/s5_port.h`; untested.
