/*
 *	line_task.c -- Line Follow: periodic 5 ms (NFR1). Owns the ADC and pins GP26 / GP27.
 *	APIs shown: tk_dly_tsk, tk_set_flg, tk_loc_mtx / tk_unl_mtx, tk_snd_mbf
 *	It never commands the motors: it publishes line_status_t for Motion Control and line_evt_t for the VC.
 */
#include "subsystem3.h"
#include "drv_line.h"
#include "line_algo.h"
#include "line_config.h"
#include "s3_port.h"

static uint32_t s_next_us;

static void period_wait(void)
{
	s_next_us += (uint32_t)LINE_PERIOD_MS * 1000u;
	int32_t delta = (int32_t)(s_next_us - S3_US32());
	if (delta <= 0) { s_next_us = S3_US32(); return; }	/* overran: do not catch up */
	uint32_t ms = (uint32_t)delta / 1000u;
	tk_dly_tsk(ms ? ms : 1);
}

static void send_evt(la_event_t e)
{
	static const int map[] = { 0, LINE_EVT_JUNCTION, LINE_EVT_LOST, LINE_EVT_FOUND };
#if S3_DEBUG_PRINT
	static const char *const nm[] = { "", "JUNCTION", "LINE_LOST", "LINE_FOUND" };
#endif
	line_evt_t ev = { map[e], s3_now_ms() };

	if (mbf_line_evt > 0) {
		tk_snd_mbf(mbf_line_evt, &ev, sizeof ev, TMO_POL);	/* never blocks; a full buffer drops it */
	} else {
#if S3_DEBUG_PRINT
		S3_PRINTF("[S3] >> %s\n", nm[e]);
#endif
	}
}

void line_task(INT stacd, void *exinf)
{
	la_t a; la_out_t o;
	int l, r;
	unsigned n = 0; (void)n;
	(void)stacd; (void)exinf;

	line_adc_init();
	la_init(&a);
	s_next_us = S3_US32();

	for (;;) {
		line_adc_read(&l, &r);
		la_step(&a, l, r, &o);

		static bool ready_sent;
		if (o.ready && !ready_sent) {
			ready_sent = true;
			tk_set_flg(flg_line, FLG_LINE_READY);
#if S3_DEBUG_PRINT
			S3_PRINTF("[S3] calibration %s: L %d..%d  R %d..%d\n", a.cal_ok ? "ok" : "REJECTED (defaults used)",
				  a.white_l, a.black_l, a.white_r, a.black_r);
#endif
		}

		if (o.ready) {
			line_status_t ls = { o.offset, o.steering_corr, o.on_line };
			if (tk_loc_mtx(mtx_line, TMO_POL) == E_OK) {	/* skip this sample if S2 is reading */
				app_line = ls;
				tk_unl_mtx(mtx_line);
			}
			if (o.event != LA_NO_EVENT)
				send_evt(o.event);
		}
		tk_set_flg(flg_line, FLG_LINE_ALIVE);

#if S3_DEBUG_PRINT
		if (++n % (500 / LINE_PERIOD_MS) == 0)
			S3_PRINTF("[S3] adc %d/%d offset=%d%% steer=%d on=%d\n", l, r,
				  (int)(o.offset * 100), (int)o.steering_corr, o.on_line);
#endif
		period_wait();
	}
}
